export const PAGES = {
    HOME: 'Home',
    REGISTRATIONS: 'Registrations',
    FIXTURES: 'Fixtures',
    LADDERS: 'Ladders',
    SHOP: 'Shop',
    ABOUT: 'About',
    COMPETITION: 'Competition',
    COMPETITION_RULES: 'Competition Rules',
    CONTACT_US: 'Contact Us',
    TERMS_AND_CONDITIONS: 'Terms and Conditions',
    PRIVACY_POLICY: 'Privacy Policy',
    NEWS: 'News',
    NEWS_DETAILS: 'NewsDetails'
}
