export default function isPointType(type) {
  return type === 'P' || type === 'MP' ? true : false;
}
