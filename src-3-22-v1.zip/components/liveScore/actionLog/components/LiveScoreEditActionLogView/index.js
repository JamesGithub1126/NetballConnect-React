import LiveScoreEditActionLogView from "./liveScoreEditActionLogView";
export default LiveScoreEditActionLogView;