import EventPlayerView from "./EventPlayerView";
export default EventPlayerView;