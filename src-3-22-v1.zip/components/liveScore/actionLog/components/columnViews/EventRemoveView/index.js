import EventRemoveView from "./EventRemoveView";
export default EventRemoveView;