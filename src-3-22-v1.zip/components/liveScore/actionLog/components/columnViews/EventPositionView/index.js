import EventPositionView from "./EventPositionView";
export default EventPositionView;