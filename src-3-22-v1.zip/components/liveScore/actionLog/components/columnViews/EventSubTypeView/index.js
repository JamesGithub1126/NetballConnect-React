import EventSubTypeView from "./EventSubTypeView";
export default EventSubTypeView;