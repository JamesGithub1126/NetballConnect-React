import EventTypeView from "./EventTypeView";
export default EventTypeView;