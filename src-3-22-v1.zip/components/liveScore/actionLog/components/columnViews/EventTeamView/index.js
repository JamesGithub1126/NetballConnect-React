import EventTeamView from "./EventTeamView";
export default EventTeamView;