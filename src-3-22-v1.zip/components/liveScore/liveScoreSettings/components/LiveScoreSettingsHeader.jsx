import React from 'react';

const LiveScoreSettingsHeader = ({ children }) => {
  return <span className="text-heading-large pt-5">{children}</span>;
};

export default LiveScoreSettingsHeader;
