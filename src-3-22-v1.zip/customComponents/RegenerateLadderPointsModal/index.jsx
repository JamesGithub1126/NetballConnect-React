import  { RegenerateLadderPointsModal }  from "./RegenerateLadderPointsModal";
export default RegenerateLadderPointsModal;